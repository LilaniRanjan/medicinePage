import React from 'react';
import PharmacyProductList from './PharmacyProductList';
import Grid from '@material-ui/core/Grid';

export default function DiabetesForMedicine(){
    return(
        <>
            <Grid container spacing={3}>
                <Grid item xs={2}/>
                <Grid item xs={8}>
                    <PharmacyProductList med ="Diabetes"/>
                </Grid>
                <Grid item xs={2}/>
            </Grid>
        </>
    )
}